import pymcprotocol
import time

#If you use Q series PLC
#pymc3e = pymcprotocol.Type3E()
#if you use L series PLC,
#pymc3e = pymcprotocol.Type3E(plctype="L")
#if you use QnA series PLC,
#pymc3e = pymcprotocol.Type3E(plctype="QnA")
#if you use iQ-L series PLC,
#pymc3e = pymcprotocol.Type3E(plctype="iQ-L")
#if you use iQ-R series PLC,
pymc3e = pymcprotocol.Type3E(plctype="iQ-R")

address = "192.168.1.232"
port = 6001

# connect to the PLC
try:
    print("connecting to PLC at " + address + ":" + str(port))
    pymc3e.setaccessopt(commtype="binary")
    pymc3e.connect(address, port)
except Exception as e: 
    print(e)
    exit()

# write from D10 to D15
pymc3e.batchwrite_wordunits(headdevice="D2000", values=[1000, 2000, 3000, 4000, 5000])

# read the values we just wrote
wordunits_values = pymc3e.batchread_wordunits(headdevice="D2000", readsize=5)
print(wordunits_values)

# read target register values
while True:
    word_values, dword_values = pymc3e.randomread(word_devices=["D5000", "D5100", "D5200", "D5300", "D5400", "D5500", "D5600", "D5700", "D5800", "D5900", "D6000", "D6100"], dword_devices=["D3000"])
    print(word_values)

# # time 100 batchwrite operations
# plc_out = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
# start = time.time()
# for i in range(100):
#     pymc3e.batchwrite_wordunits(headdevice="D2000", values=plc_out)
# end = time.time()
# print(end - start)

# # time 100 randomwrite operations
# start = time.time()
# for i in range(100):
#     pymc3e.randomwrite(word_devices=[], word_values=[], dword_devices=["D2000", "D2002", "D2004", "D2006", "D2008", "D2010", "D2012", "D2014", "D2016", "D2018", "D2020", "D2022"], dword_values=plc_out[0:12])
# end = time.time()
# print(end - start)

# # time 100 randomwrite operations
# start = time.time()
# for i in range(100):
#     plc_readings = pymc3e.batchread_wordunits(headdevice="D1018", readsize=2)
# end = time.time()
# print(end - start)