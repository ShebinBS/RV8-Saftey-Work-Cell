﻿namespace SimpleLibrarySlmpFx5
{
    class Program
    {
        static void Main(string[] args)
        {
            SimpleLibSlmpFx5.SimpleSlmp connectionPLC = new SimpleLibSlmpFx5.SimpleSlmp();
            SimpleLibSlmpFx5.SimpleSlmp connectionCntrllr = new SimpleLibSlmpFx5.SimpleSlmp();
            byte[] plcAddr = new byte[4];
            byte[] ctrllrAddr = new byte[4];
            plcAddr[0] = 192; plcAddr[1] = 168; plcAddr[2] = 0; plcAddr[3] = 250;
            ctrllrAddr[0] = 192; ctrllrAddr[1] = 168; ctrllrAddr[2] = 0; ctrllrAddr[3] = 200;
            string ans = connectionPLC.Open(plcAddr, 2000);
            //Console.WriteLine("Answer from open connection: " + ans);
            /*if (ans == string.Empty)
            {
                while (true)
                {
                    bool x0Value = false;
                    ans = connection1.ReadBit("X", 0, ref x0Value);
                    if (!x0Value)
                    {
                        ans = connection1.WriteBit("B", 0, false);
                        Console.WriteLine("DO B0 = FALSE: " + ans);
                    }
                }
            }*/
            if (ans == string.Empty)
            /*if (ans == string.Empty)
            {
                bool m10Value = false;
                ans = connection1.ReadBit("M", 10, ref m10Value);
                Console.WriteLine("Ans: " + ans + ", Read bit of M10 before invert: " + m10Value.ToString());
                //Console.ReadKey();
                bool m10ValueSet = !m10Value;
                ans = connection1.WriteBit("M", 10, m10ValueSet);
                Console.WriteLine("Write bit M10 Ans: " + ans);
                //Console.ReadKey();
                ans = connection1.ReadBit("M", 10, ref m10Value);
                Console.WriteLine("Ans: " + ans + ", Read bit of M10 after invert: " + m10Value.ToString());
                //Console.ReadKey();
                Int16 d10Value = 0;
                ans = connection1.ReadWord("D", 10, ref d10Value);
                Console.WriteLine("Ans: " + ans + ", Read value of D10 before increment: " + d10Value.ToString());
                //Console.ReadKey();
                d10Value++;
                ans = connection1.WriteWord("D", 10, d10Value);
                Console.WriteLine("Write value D10 Ans: " + ans);
                //Console.ReadKey();
                ans = connection1.ReadWord("D", 10, ref d10Value);
                Console.WriteLine("Ans: " + ans + ", Read value of D10 after increment: " + d10Value.ToString());
                //Console.ReadKey();
            }*/
            connection1.Close();
            Console.ReadKey();
        }
    }
}
